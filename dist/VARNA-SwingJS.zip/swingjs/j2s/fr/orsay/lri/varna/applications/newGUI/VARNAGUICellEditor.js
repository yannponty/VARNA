(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.applications.newGUI"),I$=[['fr.orsay.lri.varna.applications.newGUI.VARNAGUIRenderer']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "VARNAGUICellEditor", null, 'javax.swing.tree.DefaultTreeCellEditor');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._m = null;
this._base = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$javax_swing_JTree$javax_swing_tree_DefaultTreeCellRenderer$fr_orsay_lri_varna_applications_newGUI_VARNAGUITreeModel', function (tree, renderer, m) {
C$.superclazz.c$$javax_swing_JTree$javax_swing_tree_DefaultTreeCellRenderer.apply(this, [tree, renderer]);
C$.$init$.apply(this);
this._base = Clazz.new_((I$[1]||$incl$(1)).c$$javax_swing_JTree$fr_orsay_lri_varna_applications_newGUI_VARNAGUITreeModel,[tree, m]);
this._m = m;
}, 1);

Clazz.newMeth(C$, 'getTreeCellEditorComponent$javax_swing_JTree$O$Z$Z$Z$I', function (tree, value, sel, expanded, leaf, row) {
var renderer = this._base.baseElements$javax_swing_JTree$fr_orsay_lri_varna_applications_newGUI_VARNAGUITreeModel$O$Z$Z$Z$I$Z(tree, this._m, value, sel, expanded, leaf, row, true);
return renderer;
});

Clazz.newMeth(C$, 'isCellEditable$java_util_EventObject', function (evt) {
if (Clazz.instanceOf(evt, "java.awt.event.MouseEvent")) {
var clickCount;
clickCount = 1;
return (evt).getClickCount() >= clickCount;
}return true;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-09 23:13:43
