(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.export"),I$=[];
var C$=Clazz.newClass(P$, "PSExport", null, 'fr.orsay.lri.varna.models.export.SecStrDrawingProducer');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
C$.superclazz.prototype.setScale$D.apply(this, [0.4]);
}, 1);

Clazz.newMeth(C$, 'PSMacros', function () {
var setFontSize = "/setbasefont \u000a{ /Helvetica-Bold findfont\u000a  exch scalefont\u000a  setfont \u000a  } def\u000a\u000a";
var writeTextCentered = "/txtcenter \u000a{ dup \u000a  stringwidth pop\u000a  2 div neg \u000a  3 -1 roll \u000a  2 div neg\u000a  rmoveto\u000a  show\u000a  } def\u000a\u000a";
var drawEllipse = "/ellipse {\u000a  /endangle exch def\u000a  /startangle exch def\u000a  /yrad exch def\u000a  /xrad exch def\u000a  /y exch def\u000a  /x exch def\u000a  /savematrix matrix currentmatrix def\u000a  x y translate\u000a  xrad yrad scale\u000a  0 0 1 startangle endangle arc\u000a  savematrix setmatrix\u000a  } def\u000a\u000a";
return setFontSize + writeTextCentered + drawEllipse ;
});

Clazz.newMeth(C$, 'EPSHeader$D$D$D$D', function (minX, maxX, minY, maxY) {
var bbox = p$.PSBBox$D$D$D$D.apply(this, [minX, minY, maxX, maxY]);
var init = "%!PS-Adobe-3.0\u000a%%Pages: 1\u000a" + bbox + "%%EndComments\n" + "%%Page: 1 1\n" ;
var macros = p$.PSMacros.apply(this, []);
return init + macros;
});

Clazz.newMeth(C$, 'EPSFooter', function () {
return "showpage\u000a%%EndPage: 1\u000a%%EOF";
});

Clazz.newMeth(C$, 'PSNewPath', function () {
return "newpath\u000a";
});

Clazz.newMeth(C$, 'PSMoveTo$D$D', function (x, y) {
return ("" + new Double(x).toString() + " " + new Double(y).toString() + " moveto\n" );
});

Clazz.newMeth(C$, 'PSLineTo$D$D', function (dx, dy) {
return ("" + new Double(dx).toString() + " " + new Double(dy).toString() + " lineto\n" );
});

Clazz.newMeth(C$, 'PSRLineTo$D$D', function (dx, dy) {
return ("" + new Double(dx).toString() + " " + new Double(dy).toString() + " rlineto\n" );
});

Clazz.newMeth(C$, 'PSSetLineWidth$D', function (thickness) {
thickness /= 2;
return ("" + new Double(thickness).toString() + " setlinewidth\n" );
});

Clazz.newMeth(C$, 'PSStroke', function () {
return "stroke\u000a";
});

Clazz.newMeth(C$, 'PSArc$D$D$D$D$D$D', function (x, y, radiusX, radiusY, angleFrom, angleTo) {
var centerX = x;
var centerY = y;
return (new Double(centerX).toString() + " " + new Double(centerY).toString() + " " + new Double(radiusX / 2.0).toString()  + " " + new Double(radiusY / 2.0).toString() + " " + new Double(angleTo).toString() + " " + new Double(angleFrom).toString() + " ellipse\n");
});

Clazz.newMeth(C$, 'PSArc$D$D$D$D$D', function (x, y, radius, angleFrom, angleTo) {
return ("" + new Double(x).toString() + " " + new Double(y).toString() + " " + new Double(radius).toString() + " " + new Double(angleFrom).toString() + " " + new Double(angleTo).toString() + "  arc\n" );
});

Clazz.newMeth(C$, 'PSBBox$D$D$D$D', function (minX, maxX, minY, maxY) {
var norm = ("%%BoundingBox: " + (Math.floor(minX)|0) + " " + (Math.floor(minY)|0) + " " + (Math.ceil(maxX)|0) + " " + (Math.ceil(maxY)|0) + "\n" );
var high = ("%%HighResBoundingBox: " + (Math.floor(minX)|0) + " " + (Math.floor(minY)|0) + " " + (Math.ceil(maxX)|0) + " " + (Math.ceil(maxY)|0) + "\n" );
return norm + high;
});

Clazz.newMeth(C$, 'PSText$S', function (txt) {
return ("(" + txt + ") " );
});

Clazz.newMeth(C$, 'PSShow', function () {
return "show\u000a";
});

Clazz.newMeth(C$, 'PSClosePath', function () {
return "closepath\u000a";
});

Clazz.newMeth(C$, 'PSFill', function () {
return "fill\u000a";
});

Clazz.newMeth(C$, 'PSSetColor$java_awt_Color', function (col) {
return ("" + new Double(((col.getRed()) / 255.0)).toString() + " " + new Double(((col.getGreen()) / 255.0)).toString() + " " + new Double(((col.getBlue()) / 255.0)).toString() + " setrgbcolor\n" );
});

Clazz.newMeth(C$, 'fontName$I', function (font) {
switch (font) {
case (0):
return "/Times-Roman";
case (1):
return "/Times-Bold";
case (2):
return "/Times-Italic";
case (3):
return "/Times-BoldItalic";
case (16):
return "/Helvetica";
case (18):
return "/Helvetica-Bold";
case (17):
return "/Helvetica-Oblique";
case (19):
return "/Helvetica-BoldOblique";
case (12):
return "/Courier";
case (13):
return "/Courier-Bold";
case (14):
return "/Courier-Oblique";
case (15):
return "/Courier-BoldOblique";
}
return "/Helvetica";
});

Clazz.newMeth(C$, 'PSSetFont$I$D', function (font, size) {
return (p$.fontName$I.apply(this, [font]) + " findfont " + new Double(size).toString() + " scalefont setfont\n" );
});

Clazz.newMeth(C$, 'setFontS$I$D', function (font, size) {
this._fontsize = ((0.4 * size)|0);
return p$.PSSetFont$I$D.apply(this, [font, this._fontsize]);
});

Clazz.newMeth(C$, 'setColorS$java_awt_Color', function (col) {
C$.superclazz.prototype.setColorS$java_awt_Color.apply(this, [col]);
var result = p$.PSSetColor$java_awt_Color.apply(this, [col]);
return result;
});

Clazz.newMeth(C$, 'drawLineS$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double$D', function (p0, p1, thickness) {
var tmp = "";
tmp += p$.PSMoveTo$D$D.apply(this, [p0.x, p0.y]);
tmp += p$.PSLineTo$D$D.apply(this, [p1.x, p1.y]);
tmp += p$.PSSetLineWidth$D.apply(this, [thickness]);
tmp += p$.PSStroke.apply(this, []);
return tmp;
});

Clazz.newMeth(C$, 'drawTextS$java_awt_geom_Point2D_Double$S', function (p, txt) {
var tmp = "";
tmp += p$.PSMoveTo$D$D.apply(this, [p.x, p.y]);
tmp += ("" + new Double((this._fontsize / 2.0 + 1)).toString() + " \n" );
tmp += p$.PSText$S.apply(this, [txt]);
tmp += (" txtcenter\n");
return tmp;
});

Clazz.newMeth(C$, 'drawRectangleS$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double$D', function (orig, dims, thickness) {
var tmp = p$.PSNewPath.apply(this, []);
tmp += p$.PSMoveTo$D$D.apply(this, [orig.x, orig.y]);
tmp += p$.PSRLineTo$D$D.apply(this, [0, dims.y]);
tmp += p$.PSRLineTo$D$D.apply(this, [dims.x, 0]);
tmp += p$.PSRLineTo$D$D.apply(this, [0, -dims.y]);
tmp += p$.PSClosePath.apply(this, []);
tmp += p$.PSSetLineWidth$D.apply(this, [thickness]);
tmp += p$.PSStroke.apply(this, []);
return tmp;
});

Clazz.newMeth(C$, 'drawCircleS$java_awt_geom_Point2D_Double$D$D', function (p, radius, thickness) {
var tmp = p$.PSNewPath.apply(this, []);
tmp += p$.PSArc$D$D$D$D$D.apply(this, [p.x, p.y, radius, 0, 360]);
tmp += p$.PSSetLineWidth$D.apply(this, [thickness]);
tmp += p$.PSStroke.apply(this, []);
return tmp;
});

Clazz.newMeth(C$, 'fillCircleS$java_awt_geom_Point2D_Double$D$D$java_awt_Color', function (p, radius, thickness, color) {
var tmp = p$.PSNewPath.apply(this, []);
tmp += p$.PSArc$D$D$D$D$D.apply(this, [p.x, p.y, radius, 0, 360]);
tmp += p$.PSSetLineWidth$D.apply(this, [thickness]);
tmp += p$.PSSetColor$java_awt_Color.apply(this, [color]);
tmp += p$.PSFill.apply(this, []);
return tmp;
});

Clazz.newMeth(C$, 'footerS', function () {
return p$.EPSFooter.apply(this, []);
});

Clazz.newMeth(C$, 'headerS$java_awt_geom_Rectangle2D_Double', function (bb) {
return p$.EPSHeader$D$D$D$D.apply(this, [bb.x, bb.y, bb.x + bb.width, bb.y + bb.height]);
});

Clazz.newMeth(C$, 'drawArcS$java_awt_geom_Point2D_Double$D$D$D$D', function (origine, width, height, startAngle, endAngle) {
return p$.PSArc$D$D$D$D$D$D.apply(this, [origine.x, origine.y, width, height, startAngle, endAngle]) + p$.PSStroke.apply(this, []);
});

Clazz.newMeth(C$, 'drawPolygonS$java_awt_geom_Point2D_DoubleA$D', function (points, thickness) {
var tmp = p$.PSNewPath.apply(this, []);
tmp += p$.PSSetLineWidth$D.apply(this, [thickness]);
for (var i = 0; i < points.length; i++) {
if (i == 0) {
tmp += p$.PSMoveTo$D$D.apply(this, [points[i].x, points[i].y]);
} else {
tmp += p$.PSLineTo$D$D.apply(this, [points[i].x, points[i].y]);
}}
tmp += p$.PSClosePath.apply(this, []);
tmp += p$.PSStroke.apply(this, []);
return tmp;
});

Clazz.newMeth(C$, 'fillPolygonS$java_awt_geom_Point2D_DoubleA$java_awt_Color', function (points, color) {
var bck = this._curColor;
var tmp = p$.PSNewPath.apply(this, []);
for (var i = 0; i < points.length; i++) {
if (i == 0) {
tmp += p$.PSMoveTo$D$D.apply(this, [points[i].x, points[i].y]);
} else {
tmp += p$.PSLineTo$D$D.apply(this, [points[i].x, points[i].y]);
}}
tmp += p$.PSClosePath.apply(this, []);
tmp += p$.PSSetColor$java_awt_Color.apply(this, [color]);
tmp += p$.PSFill.apply(this, []);
tmp += p$.PSSetColor$java_awt_Color.apply(this, [bck]);
return tmp;
});

Clazz.newMeth(C$, 'drawBaseStartS$I', function (index) {
return "";
});

Clazz.newMeth(C$, 'drawBaseEndS$I', function (index) {
return "";
});

Clazz.newMeth(C$, 'drawBasePairStartS$I$I$fr_orsay_lri_varna_models_rna_ModeleBP', function (i, j, bps) {
return "";
});

Clazz.newMeth(C$, 'drawBasePairEndS$I', function (index) {
return "";
});

Clazz.newMeth(C$, 'drawBackboneStartS$I$I', function (i, j) {
return "";
});

Clazz.newMeth(C$, 'drawBackboneEndS$I', function (index) {
return "";
});
})();
//Created 2018-01-09 23:13:47
