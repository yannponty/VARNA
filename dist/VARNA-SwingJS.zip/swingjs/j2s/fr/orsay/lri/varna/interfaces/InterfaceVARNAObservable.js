(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.interfaces"),I$=[];
var C$=Clazz.newClass(P$, "InterfaceVARNAObservable");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-09 23:13:46
