(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.interfaces"),I$=[];
var C$=Clazz.newInterface(P$, "InterfaceVARNASelectionListener");
})();
//Created 2018-01-09 23:13:46
