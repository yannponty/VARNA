(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.exceptions"),I$=[];
var C$=Clazz.newClass(P$, "ExceptionEdgeEndpointAlreadyConnected", null, 'fr.orsay.lri.varna.exceptions.ExceptionInvalidRNATemplate');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (message) {
C$.superclazz.c$$S.apply(this, [message]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$$S.apply(this, ["Edge endpoint is already connected"]);
C$.$init$.apply(this);
}, 1);
})();
//Created 2018-01-09 23:13:46
