(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.controlers"),I$=[['javax.swing.JColorChooser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ControleurVueAnnotation", null, null, ['javax.swing.event.CaretListener', 'javax.swing.event.ChangeListener', 'java.awt.event.ActionListener']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._vueAnnot = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_views_VueAnnotation', function (vueAnnot) {
C$.$init$.apply(this);
this._vueAnnot = vueAnnot;
}, 1);

Clazz.newMeth(C$, 'caretUpdate$javax_swing_event_CaretEvent', function (arg0) {
this._vueAnnot.update();
});

Clazz.newMeth(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (arg0) {
this._vueAnnot.update();
});

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (arg0) {
if (arg0.getActionCommand().equals$O("setcolor")) {
var c = (I$[1]||$incl$(1)).showDialog$java_awt_Component$S$java_awt_Color(this._vueAnnot.get_vp(), "Pick a color", this._vueAnnot.getTextAnnotation().getColor());
if (c != null ) {
this._vueAnnot.updateColor$java_awt_Color(c);
}}this._vueAnnot.update();
});

Clazz.newMeth(C$);
})();
//Created 2018-01-09 23:13:46
