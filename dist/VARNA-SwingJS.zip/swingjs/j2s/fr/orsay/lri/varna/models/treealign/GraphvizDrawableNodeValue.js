(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.treealign"),I$=[];
var C$=Clazz.newInterface(P$, "GraphvizDrawableNodeValue");
})();
//Created 2018-01-09 23:13:49
