(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.templates"),I$=[];
var C$=Clazz.newClass(P$, "RNANodeValueTemplateSequence", null, 'fr.orsay.lri.varna.models.templates.RNANodeValueTemplate');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.sequence = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'toGraphvizNodeName', function () {
return "S(len=" + this.sequence.getLength() + ")" ;
});

Clazz.newMeth(C$, 'getSequence', function () {
return this.sequence;
});

Clazz.newMeth(C$, 'setSequence$fr_orsay_lri_varna_models_templates_RNATemplate_RNATemplateUnpairedSequence', function (sequence) {
this.sequence = sequence;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-09 23:13:49
