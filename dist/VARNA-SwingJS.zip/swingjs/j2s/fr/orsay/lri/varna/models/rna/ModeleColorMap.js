(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.rna"),I$=[['java.awt.Color','fr.orsay.lri.varna.models.rna.ModeleColorMap','java.util.Vector','java.util.Arrays',['fr.orsay.lri.varna.models.rna.ModeleColorMap','.NamedColorMapTypes'],'java.util.Formatter']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ModeleColorMap", null, null, ['Cloneable', 'java.io.Serializable']);
C$.DEFAULT_COLOR = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.DEFAULT_COLOR = (I$[1]||$incl$(1)).GREEN;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._map = null;
this._values = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$java_util_Vector$java_util_Vector.apply(this, [Clazz.new_((I$[3]||$incl$(3))), Clazz.new_((I$[3]||$incl$(3)))]);
}, 1);

Clazz.newMeth(C$, 'c$$java_util_Vector$java_util_Vector', function (map, values) {
C$.$init$.apply(this);
this._map = map;
this._values = values;
}, 1);

Clazz.newMeth(C$, 'addColor$D$java_awt_Color', function (val, col) {
var offset = (I$[4]||$incl$(4)).binarySearch$OA$O(this._values.toArray(), new Double(val));
if (offset < 0) {
var inspoint = (-offset) - 1;
this._map.insertElementAt$TE$I(col, inspoint);
this._values.insertElementAt$TE$I(new Double(val), inspoint);
}});

Clazz.newMeth(C$, 'getMinValue', function () {
if (this._values.size() > 0) return (this._values.get$I(0)).doubleValue();
return 0.0;
});

Clazz.newMeth(C$, 'getMaxValue', function () {
if (this._values.size() > 0) return (this._values.get$I(this._values.size() - 1)).doubleValue();
return 0.0;
});

Clazz.newMeth(C$, 'getMinColor', function () {
if (this._map.size() > 0) return this._map.get$I(0);
return C$.DEFAULT_COLOR;
});

Clazz.newMeth(C$, 'getMaxColor', function () {
if (this._map.size() > 0) return this._map.get$I(this._map.size() - 1);
return C$.DEFAULT_COLOR;
});

Clazz.newMeth(C$, 'getNumColors', function () {
return (this._map.size());
});

Clazz.newMeth(C$, 'getColorAt$I', function (i) {
return (this._map.get$I(i));
});

Clazz.newMeth(C$, 'getValueAt$I', function (i) {
return (this._values.get$I(i));
});

Clazz.newMeth(C$, 'getColorForValue$D', function (val) {
var result;
if (val <= this.getMinValue() ) {
result = this.getMinColor();
} else if (val >= this.getMaxValue() ) {
result = this.getMaxColor();
} else {
var offset = (I$[4]||$incl$(4)).binarySearch$OA$O(this._values.toArray(), new Double(val));
if (offset >= 0) {
result = this._map.get$I(offset);
} else {
var inspoint = (-offset) - 1;
var c1 = this._map.get$I(inspoint);
var v1 = (this._values.get$I(inspoint)).doubleValue();
if (inspoint > 0) {
var c2 = this._map.get$I(inspoint - 1);
var v2 = (this._values.get$I(inspoint - 1)).doubleValue();
var blendCoeff = (v2 - val) / (v2 - v1);
result = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[((blendCoeff * c1.getRed() + (1.0 - blendCoeff) * c2.getRed())|0), ((blendCoeff * c1.getGreen() + (1.0 - blendCoeff) * c2.getGreen())|0), ((blendCoeff * c1.getBlue() + (1.0 - blendCoeff) * c2.getBlue())|0)]);
} else {
result = c1;
}}}return result;
});

Clazz.newMeth(C$, 'energyColorMap', function () {
var cm = Clazz.new_(C$);
cm.addColor$D$java_awt_Color(1.0, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[128, 50, 50]).brighter());
cm.addColor$D$java_awt_Color(0.9, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[255, 50, 50]).brighter());
cm.addColor$D$java_awt_Color(0.65, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[255, 255, 50]).brighter());
cm.addColor$D$java_awt_Color(0.55, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[20, 255, 50]).brighter());
cm.addColor$D$java_awt_Color(0.2, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[50, 50, 255]).brighter());
cm.addColor$D$java_awt_Color(0.0, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[50, 50, 128]).brighter());
return cm;
}, 1);

Clazz.newMeth(C$, 'viennaColorMap', function () {
var cm = Clazz.new_(C$);
cm.addColor$D$java_awt_Color(0.0, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[0, 80, 220]));
cm.addColor$D$java_awt_Color(0.1, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[0, 139, 220]));
cm.addColor$D$java_awt_Color(0.2, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[0, 220, 218]));
cm.addColor$D$java_awt_Color(0.3, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[0, 220, 123]));
cm.addColor$D$java_awt_Color(0.4, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[0, 220, 49]));
cm.addColor$D$java_awt_Color(0.5, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[34, 220, 0]));
cm.addColor$D$java_awt_Color(0.6, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[109, 220, 0]));
cm.addColor$D$java_awt_Color(0.7, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[199, 220, 0]));
cm.addColor$D$java_awt_Color(0.8, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[220, 165, 0]));
cm.addColor$D$java_awt_Color(0.9, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[220, 86, 0]));
cm.addColor$D$java_awt_Color(1.0, Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[220, 0, 0]));
return cm;
}, 1);

Clazz.newMeth(C$, 'bwColorMap', function () {
var cm = Clazz.new_(C$);
cm.addColor$D$java_awt_Color(0.0, (I$[1]||$incl$(1)).white);
cm.addColor$D$java_awt_Color(1.0, (I$[1]||$incl$(1)).gray.darker());
return cm;
}, 1);

Clazz.newMeth(C$, 'greenColorMap', function () {
var cm = Clazz.new_(C$);
cm.addColor$D$java_awt_Color(0.0, (I$[1]||$incl$(1)).gray.brighter().brighter());
cm.addColor$D$java_awt_Color(1.0, (I$[1]||$incl$(1)).green.darker());
return cm;
}, 1);

Clazz.newMeth(C$, 'blueColorMap', function () {
var cm = Clazz.new_(C$);
cm.addColor$D$java_awt_Color(0.0, (I$[1]||$incl$(1)).gray.brighter().brighter());
cm.addColor$D$java_awt_Color(1.0, (I$[1]||$incl$(1)).blue);
return cm;
}, 1);

Clazz.newMeth(C$, 'redColorMap', function () {
var cm = Clazz.new_(C$);
cm.addColor$D$java_awt_Color(0.0, (I$[1]||$incl$(1)).gray.brighter().brighter());
cm.addColor$D$java_awt_Color(1.0, (I$[1]||$incl$(1)).red);
return cm;
}, 1);

Clazz.newMeth(C$, 'heatColorMap', function () {
var cm = Clazz.new_(C$);
cm.addColor$D$java_awt_Color(0.0, (I$[1]||$incl$(1)).yellow);
cm.addColor$D$java_awt_Color(1.0, (I$[1]||$incl$(1)).red);
return cm;
}, 1);

Clazz.newMeth(C$, 'rockNRollColorMap', function () {
var cm = Clazz.new_(C$);
cm.addColor$D$java_awt_Color(0.0, (I$[1]||$incl$(1)).red.brighter());
cm.addColor$D$java_awt_Color(1.0, (I$[1]||$incl$(1)).black);
cm.addColor$D$java_awt_Color(2.0, (I$[1]||$incl$(1)).green.brighter());
return cm;
}, 1);

Clazz.newMeth(C$, 'defaultColorMap', function () {
return C$.energyColorMap();
}, 1);

Clazz.newMeth(C$, 'parseColorMap$S', function (s) {
var data = s.$plit("[;,]");
if (data.length == 1) {
var name = data[0].toLowerCase();
for (var p, $p = 0, $$p = (I$[5]||$incl$(5)).values(); $p<$$p.length&&((p=$$p[$p]),1);$p++) {
if (name.equals$O(p.getId().toLowerCase())) {
return p.getColorMap();
}}
return C$.defaultColorMap();
} else {
var cm = Clazz.new_(C$);
for (var i = 0; i < data.length; i++) {
var data2 = data[i].$plit(":");
if (data2.length == 2) {
try {
var val = new Double(Double.parseDouble(data2[0]));
var col = (I$[1]||$incl$(1)).decode$S(data2[1]);
cm.addColor$D$java_awt_Color((val).doubleValue(), col);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
}}
if (cm.getNumColors() > 1) return cm;
}return C$.defaultColorMap();
}, 1);

Clazz.newMeth(C$, 'setMinValue$D', function (newMin) {
this.rescale$D$D(newMin, this.getMaxValue());
});

Clazz.newMeth(C$, 'setMaxValue$D', function (newMax) {
this.rescale$D$D(this.getMinValue(), newMax);
});

Clazz.newMeth(C$, 'rescale$D$D', function (newMin, newMax) {
var minBck = this.getMinValue();
var maxBck = this.getMaxValue();
var spanBck = maxBck - minBck;
if (newMax != newMin ) {
newMax = Math.max(newMax, newMin + 1.0);
for (var i = 0; i < this._values.size(); i++) {
var valBck = (this._values.get$I(i)).doubleValue();
this._values.set$I$TE(i, new Double(newMin + (newMax - newMin) * (valBck - minBck) / (spanBck)));
}
}});

Clazz.newMeth(C$, 'clone', function () {
var cm = Clazz.new_(C$);
cm._map = this._map.clone();
cm._values = this._values.clone();
return cm;
});

Clazz.newMeth(C$, 'equals$fr_orsay_lri_varna_models_rna_ModeleColorMap', function (cm) {
if (this.getNumColors() != cm.getNumColors()) return false;
for (var i = 0; i < this.getNumColors(); i++) {
if ((!this.getColorAt$I(i).equals$O(cm.getColorAt$I(i))) || (!this.getValueAt$I(i).equals(cm.getValueAt$I(i))) ) return false;
}
return true;
});

Clazz.newMeth(C$, 'getParamEncoding', function () {
var result = "";
var f = Clazz.new_((I$[6]||$incl$(6)));
for (var i = 0; i < this.getNumColors(); i++) {
if (i != 0) f.format$S$OA(",", []);
f.format$S$OA("%.2f:#%02X%02X%02X", [this._values.get$I(i), new Integer(this._map.get$I(i).getRed()), new Integer(this._map.get$I(i).getGreen()), new Integer(this._map.get$I(i).getBlue())]);
}
return f.out().toString();
});

Clazz.newMeth(C$, 'toString', function () {
return this.getParamEncoding();
});
;
(function(){var C$=Clazz.newClass(P$.ModeleColorMap, "NamedColorMapTypes", null, 'Enum');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$$S$fr_orsay_lri_varna_models_rna_ModeleColorMap, "RED", 0, ["red", (I$[2]||$incl$(2)).redColorMap()]);
Clazz.newEnumConst($vals, C$.c$$S$fr_orsay_lri_varna_models_rna_ModeleColorMap, "BLUE", 1, ["blue", (I$[2]||$incl$(2)).blueColorMap()]);
Clazz.newEnumConst($vals, C$.c$$S$fr_orsay_lri_varna_models_rna_ModeleColorMap, "GREEN", 2, ["green", (I$[2]||$incl$(2)).greenColorMap()]);
Clazz.newEnumConst($vals, C$.c$$S$fr_orsay_lri_varna_models_rna_ModeleColorMap, "HEAT", 3, ["heat", (I$[2]||$incl$(2)).heatColorMap()]);
Clazz.newEnumConst($vals, C$.c$$S$fr_orsay_lri_varna_models_rna_ModeleColorMap, "ENERGY", 4, ["energy", (I$[2]||$incl$(2)).energyColorMap()]);
Clazz.newEnumConst($vals, C$.c$$S$fr_orsay_lri_varna_models_rna_ModeleColorMap, "ROCKNROLL", 5, ["rocknroll", (I$[2]||$incl$(2)).rockNRollColorMap()]);
Clazz.newEnumConst($vals, C$.c$$S$fr_orsay_lri_varna_models_rna_ModeleColorMap, "VIENNA", 6, ["vienna", (I$[2]||$incl$(2)).viennaColorMap()]);
Clazz.newEnumConst($vals, C$.c$$S$fr_orsay_lri_varna_models_rna_ModeleColorMap, "BW", 7, ["bw", (I$[2]||$incl$(2)).bwColorMap()]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._id = null;
this._cm = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S$fr_orsay_lri_varna_models_rna_ModeleColorMap', function (id, cm) {
C$.$init$.apply(this);
this._id = id;
this._cm = cm;
}, 1);

Clazz.newMeth(C$, 'getId', function () {
return this._id;
});

Clazz.newMeth(C$, 'getColorMap', function () {
return this._cm;
});

Clazz.newMeth(C$, 'toString', function () {
return this._id;
});

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values', function() { return $vals }, 1);
})()
})();
//Created 2018-01-09 23:13:48
