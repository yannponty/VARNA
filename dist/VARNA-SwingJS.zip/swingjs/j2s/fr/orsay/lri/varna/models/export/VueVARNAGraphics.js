(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.export"),I$=[];
var C$=Clazz.newInterface(P$, "VueVARNAGraphics");
})();
//Created 2018-01-09 23:13:47
