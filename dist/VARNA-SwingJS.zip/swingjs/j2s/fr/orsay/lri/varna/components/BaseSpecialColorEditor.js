(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.components"),I$=[['javax.swing.JButton','fr.orsay.lri.varna.controlers.ControleurBaseSpecialColorEditor','javax.swing.JColorChooser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "BaseSpecialColorEditor", null, 'javax.swing.AbstractCellEditor', 'javax.swing.table.TableCellEditor');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.currentColor = null;
this.button = null;
this.colorChooser = null;
this.dialog = null;
this._vueBases = null;
this._controleurSpecialColorEditor = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_views_VueBases', function (vueBases) {
Clazz.super_(C$, this,1);
this.button = Clazz.new_((I$[1]||$incl$(1)));
this.button.setActionCommand$S("edit");
this._controleurSpecialColorEditor = Clazz.new_((I$[2]||$incl$(2)).c$$fr_orsay_lri_varna_components_BaseSpecialColorEditor,[this]);
this.button.addActionListener$java_awt_event_ActionListener(this._controleurSpecialColorEditor);
this.button.setBorderPainted$Z(false);
this.fireEditingStopped();
this._vueBases = vueBases;
this.colorChooser = Clazz.new_((I$[3]||$incl$(3)));
this.dialog = (I$[3]||$incl$(3)).createDialog$java_awt_Component$S$Z$javax_swing_JColorChooser$java_awt_event_ActionListener$java_awt_event_ActionListener(this.button, "Pick a Color", true, this.colorChooser, this._controleurSpecialColorEditor, null);
}, 1);

Clazz.newMeth(C$, 'getCellEditorValue', function () {
return this.currentColor;
});

Clazz.newMeth(C$, 'getTableCellEditorComponent$javax_swing_JTable$O$Z$I$I', function (table, value, isSelected, row, column) {
this.currentColor = value;
return this.button;
});

Clazz.newMeth(C$, 'getSerialVersionUID', function () {
return 1;
}, 1);

Clazz.newMeth(C$, 'getCurrentColor', function () {
return this.currentColor;
});

Clazz.newMeth(C$, 'getButton', function () {
return this.button;
});

Clazz.newMeth(C$, 'getColorChooser', function () {
return this.colorChooser;
});

Clazz.newMeth(C$, 'getDialog', function () {
return this.dialog;
});

Clazz.newMeth(C$, 'getEDIT', function () {
return "edit";
}, 1);

Clazz.newMeth(C$, 'get_vueBases', function () {
return this._vueBases;
});

Clazz.newMeth(C$, 'get_controleurSpecialColorEditor', function () {
return this._controleurSpecialColorEditor;
});

Clazz.newMeth(C$, 'setCurrentColor$java_awt_Color', function (currentColor) {
this.currentColor = currentColor;
});

Clazz.newMeth(C$, 'callFireEditingStopped', function () {
this.fireEditingStopped();
});

Clazz.newMeth(C$);
})();
//Created 2018-01-09 23:13:44
