(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.applications"),I$=[['javax.swing.JPanel','javax.swing.JLabel','javax.swing.JTextField','javax.swing.JButton','fr.orsay.lri.varna.models.rna.RNA','java.awt.Color','fr.orsay.lri.varna.VARNAPanel','java.awt.Dimension','java.awt.Font','fr.orsay.lri.varna.applications.AlignmentDemo$1','java.awt.BorderLayout','java.awt.GridLayout']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AlignmentDemo", null, 'javax.swing.JFrame');
C$.errorOpt = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.errorOpt = "error";
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._vpMaster = null;
this._tools = null;
this._input = null;
this._seq1Panel = null;
this._seq2Panel = null;
this._struct1Panel = null;
this._struct2Panel = null;
this._info = null;
this._struct1 = null;
this._struct2 = null;
this._seq1 = null;
this._seq2 = null;
this._struct1Label = null;
this._struct2Label = null;
this._seq1Label = null;
this._seq2Label = null;
this._goButton = null;
this._str1Backup = null;
this._str2Backup = null;
this._seq1Backup = null;
this._seq2Backup = null;
this._RNA = null;
this._error = false;
this._backgroundColor = null;
this._algoCode = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this._tools = Clazz.new_((I$[1]||$incl$(1)));
this._input = Clazz.new_((I$[1]||$incl$(1)));
this._seq1Panel = Clazz.new_((I$[1]||$incl$(1)));
this._seq2Panel = Clazz.new_((I$[1]||$incl$(1)));
this._struct1Panel = Clazz.new_((I$[1]||$incl$(1)));
this._struct2Panel = Clazz.new_((I$[1]||$incl$(1)));
this._info = Clazz.new_((I$[2]||$incl$(2)));
this._struct1 = Clazz.new_((I$[3]||$incl$(3)).c$$S,["(((((.(((((----....----))))).(((((....)))))..)))))"]);
this._struct2 = Clazz.new_((I$[3]||$incl$(3)).c$$S,["(((((.(((((((((....))))))))).--------------..)))))"]);
this._seq1 = Clazz.new_((I$[3]||$incl$(3)).c$$S,["CGCGCACGCGA----UAUU----UCGCGUCGCGCAUUUGCGCGUAGCGCG"]);
this._seq2 = Clazz.new_((I$[3]||$incl$(3)).c$$S,["CGCGCACGCGSGCGCGUUUGCGCUCGCGU---------------AGCGCG"]);
this._struct1Label = Clazz.new_((I$[2]||$incl$(2)).c$$S,[" Str1:"]);
this._struct2Label = Clazz.new_((I$[2]||$incl$(2)).c$$S,[" Str2:"]);
this._seq1Label = Clazz.new_((I$[2]||$incl$(2)).c$$S,[" Seq1:"]);
this._seq2Label = Clazz.new_((I$[2]||$incl$(2)).c$$S,[" Seq2:"]);
this._goButton = Clazz.new_((I$[4]||$incl$(4)).c$$S,["Go"]);
this._str1Backup = "";
this._str2Backup = "";
this._seq1Backup = "";
this._seq2Backup = "";
this._RNA = Clazz.new_((I$[5]||$incl$(5)));
this._backgroundColor = (I$[6]||$incl$(6)).white;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this._vpMaster = Clazz.new_((I$[7]||$incl$(7)).c$$S$S$S$S$I$S,[this.getSeq1(), this.getStruct1(), this.getSeq2(), this.getStruct2(), 2, ""]);
this._vpMaster.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[600, 400]));
p$.RNAPanelDemoInit.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'RNAPanelDemoInit', function () {
var marginTools = 40;
this.setBackground$java_awt_Color(this._backgroundColor);
this._vpMaster.setBackground$java_awt_Color(this._backgroundColor);
var textFieldsFont = (I$[9]||$incl$(9)).decode$S("MonoSpaced-PLAIN-12");
this._goButton.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "AlignmentDemo$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['fr.orsay.lri.varna.applications.AlignmentDemo']._vpMaster.drawRNA$S$S$S$S$I(this.b$['fr.orsay.lri.varna.applications.AlignmentDemo'].getSeq1(), this.b$['fr.orsay.lri.varna.applications.AlignmentDemo'].getStruct1(), this.b$['fr.orsay.lri.varna.applications.AlignmentDemo'].getSeq2(), this.b$['fr.orsay.lri.varna.applications.AlignmentDemo'].getStruct2(), this.b$['fr.orsay.lri.varna.applications.AlignmentDemo']._vpMaster.getDrawMode());
this.b$['fr.orsay.lri.varna.applications.AlignmentDemo']._vpMaster.repaint();
});
})()
), Clazz.new_((I$[10]||$incl$(10)).$init$, [this, null])));
this._seq1Label.setHorizontalTextPosition$I(2);
this._seq1Label.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[marginTools, 15]));
this._seq1.setFont$java_awt_Font(textFieldsFont);
this._seq1Panel.setLayout$java_awt_LayoutManager(Clazz.new_((I$[11]||$incl$(11))));
this._seq1Panel.add$java_awt_Component$O(this._seq1Label, "West");
this._seq1Panel.add$java_awt_Component$O(this._seq1, "Center");
this._seq2Label.setHorizontalTextPosition$I(2);
this._seq2Label.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[marginTools, 15]));
this._seq2.setFont$java_awt_Font(textFieldsFont);
this._seq2Panel.setLayout$java_awt_LayoutManager(Clazz.new_((I$[11]||$incl$(11))));
this._seq2Panel.add$java_awt_Component$O(this._seq2Label, "West");
this._seq2Panel.add$java_awt_Component$O(this._seq2, "Center");
this._struct1Label.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[marginTools, 15]));
this._struct1Label.setHorizontalTextPosition$I(2);
this._struct1.setFont$java_awt_Font(textFieldsFont);
this._struct1Panel.setLayout$java_awt_LayoutManager(Clazz.new_((I$[11]||$incl$(11))));
this._struct1Panel.add$java_awt_Component$O(this._struct1Label, "West");
this._struct1Panel.add$java_awt_Component$O(this._struct1, "Center");
this._struct2Label.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[marginTools, 15]));
this._struct2Label.setHorizontalTextPosition$I(2);
this._struct2.setFont$java_awt_Font(textFieldsFont);
this._struct2Panel.setLayout$java_awt_LayoutManager(Clazz.new_((I$[11]||$incl$(11))));
this._struct2Panel.add$java_awt_Component$O(this._struct2Label, "West");
this._struct2Panel.add$java_awt_Component$O(this._struct2, "Center");
this._input.setLayout$java_awt_LayoutManager(Clazz.new_((I$[12]||$incl$(12)).c$$I$I,[4, 0]));
this._input.add$java_awt_Component(this._seq1Panel);
this._input.add$java_awt_Component(this._struct1Panel);
this._input.add$java_awt_Component(this._seq2Panel);
this._input.add$java_awt_Component(this._struct2Panel);
var goPanel = Clazz.new_((I$[1]||$incl$(1)));
goPanel.setLayout$java_awt_LayoutManager(Clazz.new_((I$[11]||$incl$(11))));
this._tools.setLayout$java_awt_LayoutManager(Clazz.new_((I$[11]||$incl$(11))));
this._tools.add$java_awt_Component$O(this._input, "Center");
this._tools.add$java_awt_Component$O(this._info, "South");
this._tools.add$java_awt_Component$O(goPanel, "East");
goPanel.add$java_awt_Component$O(this._goButton, "Center");
this.getContentPane().setLayout$java_awt_LayoutManager(Clazz.new_((I$[11]||$incl$(11))));
var VARNAs = Clazz.new_((I$[1]||$incl$(1)));
VARNAs.setLayout$java_awt_LayoutManager(Clazz.new_((I$[12]||$incl$(12)).c$$I$I,[1, 1]));
VARNAs.add$java_awt_Component(this._vpMaster);
this.getContentPane().add$java_awt_Component$O(VARNAs, "Center");
this.getContentPane().add$java_awt_Component$O(this._tools, "South");
this.setVisible$Z(true);
this._vpMaster.getVARNAUI().UIRadiate();
});

Clazz.newMeth(C$, 'getRNA', function () {
if (!(this._str1Backup.equals$O(this.getStruct1()) && this._str2Backup.equals$O(this.getStruct2()) && this._seq1Backup.equals$O(this.getSeq1()) && this._seq2Backup.equals$O(this.getSeq2())  )) {
this._vpMaster.drawRNA$S$S$S$S$I(this.getSeq1(), this.getStruct1(), this.getSeq2(), this.getStruct2(), this._vpMaster.getDrawMode());
this._RNA = this._vpMaster.getRNA();
this._str1Backup = this.getStruct1();
this._str2Backup = this.getStruct2();
this._seq1Backup = this.getSeq1();
this._seq2Backup = this.getSeq2();
}return this._RNA;
});

Clazz.newMeth(C$, 'getStruct1', function () {
return p$.cleanStruct$S.apply(this, [this._struct1.getText()]);
});

Clazz.newMeth(C$, 'getStruct2', function () {
return p$.cleanStruct$S.apply(this, [this._struct2.getText()]);
});

Clazz.newMeth(C$, 'getSeq1', function () {
return p$.cleanStruct$S.apply(this, [this._seq1.getText()]);
});

Clazz.newMeth(C$, 'getSeq2', function () {
return p$.cleanStruct$S.apply(this, [this._seq2.getText()]);
});

Clazz.newMeth(C$, 'cleanStruct$S', function (struct) {
struct = struct.replaceAll$S$S("[:-]", "-");
return struct;
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var info = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["sequenceDBN", "String", "A raw RNA sequence"]), Clazz.array(java.lang.String, -1, ["structureDBN", "String", "An RNA structure in dot bracket notation (DBN)"]), Clazz.array(java.lang.String, -1, [C$.errorOpt, "boolean", "To show errors"])]);
return info;
});

Clazz.newMeth(C$, 'init', function () {
this._vpMaster.setBackground$java_awt_Color(this._backgroundColor);
this._error = true;
});

Clazz.newMeth(C$, 'getSafeColor$S$java_awt_Color', function (col, def) {
var result;
try {
result = (I$[6]||$incl$(6)).decode$S(col);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
try {
result = (I$[6]||$incl$(6)).getColor$S$java_awt_Color(col, def);
} catch (e2) {
if (Clazz.exceptionOf(e2, "java.lang.Exception")){
return def;
} else {
throw e2;
}
}
} else {
throw e;
}
}
return result;
});

Clazz.newMeth(C$, 'get_varnaPanel', function () {
return this._vpMaster;
});

Clazz.newMeth(C$, 'set_varnaPanel$fr_orsay_lri_varna_VARNAPanel', function (surface) {
this._vpMaster = surface;
});

Clazz.newMeth(C$, 'get_struct', function () {
return this._struct1;
});

Clazz.newMeth(C$, 'set_struct$javax_swing_JTextField', function (_struct) {
this._struct1 = _struct;
});

Clazz.newMeth(C$, 'get_seq', function () {
return this._seq1;
});

Clazz.newMeth(C$, 'set_seq$javax_swing_JTextField', function (_seq) {
this._seq1 = _seq;
});

Clazz.newMeth(C$, 'get_info', function () {
return this._info;
});

Clazz.newMeth(C$, 'set_info$javax_swing_JLabel', function (_info) {
this._info = _info;
});

Clazz.newMeth(C$, 'main', function (args) {
var d = Clazz.new_(C$);
d.setDefaultCloseOperation$I(3);
d.pack();
d.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'onWarningEmitted$S', function (s) {
});
})();
//Created 2018-01-10 10:00:49
