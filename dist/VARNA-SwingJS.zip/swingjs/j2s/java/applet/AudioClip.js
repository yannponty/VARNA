(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AudioClip");
})();
//Created 2018-01-06 13:29:10
