(function(){var P$=Clazz.newPackage("java.awt.geom"),I$=[];
var C$=Clazz.newInterface(P$, "PathIterator");
})();
//Created 2018-01-06 13:29:22
