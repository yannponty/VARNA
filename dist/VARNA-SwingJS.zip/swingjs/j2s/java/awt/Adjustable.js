(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Adjustable");
})();
//Created 2018-01-06 13:29:10
